(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["product-detail-page-product-detail-page-module"],{

/***/ "6xix":
/*!***************************************************************************!*\
  !*** ./src/app/product-detail-page/product-detail-page-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: ProductDetailPagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDetailPagePageRoutingModule", function() { return ProductDetailPagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _product_detail_page_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./product-detail-page.page */ "gprM");




const routes = [
    {
        path: '',
        component: _product_detail_page_page__WEBPACK_IMPORTED_MODULE_3__["ProductDetailPagePage"]
    }
];
let ProductDetailPagePageRoutingModule = class ProductDetailPagePageRoutingModule {
};
ProductDetailPagePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProductDetailPagePageRoutingModule);



/***/ }),

/***/ "Lwt6":
/*!*******************************************************************!*\
  !*** ./src/app/product-detail-page/product-detail-page.module.ts ***!
  \*******************************************************************/
/*! exports provided: ProductDetailPagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDetailPagePageModule", function() { return ProductDetailPagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _product_detail_page_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./product-detail-page-routing.module */ "6xix");
/* harmony import */ var _product_detail_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./product-detail-page.page */ "gprM");







let ProductDetailPagePageModule = class ProductDetailPagePageModule {
};
ProductDetailPagePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _product_detail_page_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductDetailPagePageRoutingModule"]
        ],
        declarations: [_product_detail_page_page__WEBPACK_IMPORTED_MODULE_6__["ProductDetailPagePage"]]
    })
], ProductDetailPagePageModule);



/***/ }),

/***/ "Zr+e":
/*!*********************************!*\
  !*** ./src/app/item.service.ts ***!
  \*********************************/
/*! exports provided: ItemService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemService", function() { return ItemService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/auth */ "UbJi");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase/app */ "Jgta");






//import { url } from 'inspector';
let ItemService = class ItemService {
    constructor(firebase, angularFire) {
        this.firebase = firebase;
        this.angularFire = angularFire;
        this.usertype = "";
        this.uid = '';
        this.menuList = [{ name: "Pasta", price: 5.50, url: "https://www.budgetbytes.com/wp-content/uploads/2013/07/Creamy-Tomato-Spinach-Pasta-V2-bowl.jpg", description: "" },
            { name: "Soup", price: 5.50, url: "https://www.inspiredtaste.net/wp-content/uploads/2018/10/Homemade-Vegetable-Soup-Recipe-4-1200.jpg", description: "" },
            { name: "Burger", price: 15, url: "https://media1.s-nbcnews.com/j/newscms/2019_21/2870431/190524-classic-american-cheeseburger-ew-207p_d9270c5c545b30ea094084c7f2342eb4.fit-2000w.jpg", description: "" },
            { name: "Fruit", price: 9, url: "https://tastesbetterfromscratch.com/wp-content/uploads/2017/06/Fresh-Fruit-Bowl-1-768x1152.jpg", description: "" },
            { name: "Cake", price: 6.20, url: "https://images.immediate.co.uk/production/volatile/sites/2/2019/04/Choc-Fudge-Cake-b2d1909.jpg?webp=true&quality=90&crop=25px%2C1960px%2C5975px%2C2570px&resize=940%2C399", description: "" },
        ];
        this.orderList = [
            { id: 1, quantity: 10, date: '2021-2-10', amount: 23.0 },
            { id: 2, quantity: 10, date: '2021-2-10', amount: 23.0 },
        ];
        this.cartCollection = this.firebase.collection('cart');
        this.orderCollection = this.firebase.collection('orders');
        this.menuCollection = this.firebase.collection('menus');
        this.menu = this.menuCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(actions => {
            return actions.map(a => {
                const data = a.payload.doc.data();
                console.log("menu data...");
                console.log(data);
                const id = a.payload.doc.id;
                return Object.assign({ id }, data);
            });
        }));
        this.order = this.orderCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(actions => {
            return actions.map(a => {
                const data = a.payload.doc.data();
                console.log("Order Data...");
                console.log(data);
                const id = a.payload.doc.id;
                return Object.assign({ id }, data);
            });
        }));
        this.cart = this.cartCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(actions => {
            return actions.map(a => {
                const data = a.payload.doc.data();
                console.log("cart data...");
                console.log(data);
                const id = a.payload.doc.id;
                return Object.assign({ id }, data);
            });
        }));
    }
    load_my_orders() {
        var user = firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth().currentUser;
        console.log(user.uid);
        var uid = user.uid;
        this.orderCollection = this.firebase.collection('orders', ref => ref.where('id', '==', uid));
        this.order = this.orderCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(actions => {
            return actions.map(a => {
                const data = a.payload.doc.data();
                const id = a.payload.doc.id;
                console.log(id);
                return Object.assign({ id }, data);
            });
        }));
        console.log("orders loaded...");
    }
    // load_my_orders(){ //after user login, call this function
    //   var user = firebase.auth().currentUser;
    //   console.log(user.uid);
    //   var uid=user.uid;
    //   // this.noteCollection = this.afs.collection<Note>('notes');
    //   this.orderCollection = this.firebase.collection<Order>('orders',ref => ref.where('uid', '==', uid));
    //   this.order = this.orderCollection.snapshotChanges().pipe(
    //       map(actions => {
    //         return actions.map(a => {
    //           const data = a.payload.doc.data();
    //           // console.log(data)
    //           const id = a.payload.doc.id;
    //           console.log(id)
    //           // console.log("run after aadding new node? ")
    //           return { id, ...data };
    //         });
    //       })
    //   );
    //   console.log("orders  loaded...")
    // }
    setUID(uid) {
        this.uid = uid;
        console.log(this.uid);
    }
    setUsertype(type) {
        this.usertype = type;
    }
    getUsertype() {
        return this.usertype;
    }
    createItem(name, price, url, description) {
        this.menuList.push({ name, price, url, description });
        //this.storage.set('menuList', JSON.stringify(this.menuList));
        var db = this.firebase;
        db.collection("menus").add({
            name: name,
            price: price,
            url: url,
            description: description,
        })
            .then((docRef) => {
            console.log("Document written with ID: ", docRef.id);
        })
            .catch((error) => {
            console.error("Error adding document: ", error);
        });
    }
    // getOrderList(){
    //   return this.orderList;
    // }
    createOrder(item, quantityY) {
        //this.orderList.push({item, quantity});
        var db = this.firebase;
        var d = new Date();
        var user = firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth().currentUser;
        console.log(user.uid);
        var uid = user.uid;
        db.collection("orders").add({
            name: item.name,
            item: item,
            quantity: quantityY,
            date: d.toLocaleDateString(),
            amount: quantityY * item.price,
            uid: uid,
        })
            .then((docRef) => {
            console.log("Document written with ID: ", docRef.id);
        })
            .catch((error) => {
            console.error("Error adding document: ", error);
            // });
            // console.log(item)
            // console.log(quantityY)
            // let orderid=Math.random()*(99999-10000)+10000;
            // var d=new Date();
            // this.orderList.push({
            //   id:orderid,
            //   quantity:quantityY,
            //   date: d.toLocaleDateString(),
            //   amount:quantityY*item.price
            // });
        });
    }
    getOrder() {
        return this.order;
    }
    getCart() {
        return this.cart;
    }
    getMenus() {
        return this.menu;
    }
    getSingleMenu(id) {
        return this.menuCollection.doc(id).valueChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(menu => {
            menu.id = id;
            return menu;
        }));
    }
    updateProductInfo(menu) {
        return this.menuCollection.doc(menu.id).update({ name: menu.name, price: menu.price, url: menu.url, description: menu.description });
    }
    deleteItem(id) {
        return this.menuCollection.doc(id).delete();
    }
    deleteOrder(id) {
        return this.orderCollection.doc(id).delete();
    }
};
ItemService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"] },
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__["AngularFireAuth"] }
];
ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ItemService);



/***/ }),

/***/ "gprM":
/*!*****************************************************************!*\
  !*** ./src/app/product-detail-page/product-detail-page.page.ts ***!
  \*****************************************************************/
/*! exports provided: ProductDetailPagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDetailPagePage", function() { return ProductDetailPagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_product_detail_page_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./product-detail-page.page.html */ "yfrp");
/* harmony import */ var _product_detail_page_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./product-detail-page.page.scss */ "v1NZ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _item_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../item.service */ "Zr+e");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/fire/auth */ "UbJi");




//import { ActivatedRoute } from '@angular/router';

//import {AddProductPagePage} from '../add-product-page';


//import {FirebaseService} from '../services/firebase.service';

let ProductDetailPagePage = class ProductDetailPagePage {
    constructor(itemService, route, router, alertController, afAuth) {
        this.itemService = itemService;
        this.route = route;
        this.router = router;
        this.alertController = alertController;
        this.afAuth = afAuth;
        this.item = null;
        this.order = { quantity: 1 };
        this.showme = false;
    }
    ngOnInit() {
        console.log("OnInit product detail page");
        this.route.params.subscribe(param => {
            this.item = param;
            console.log(this.item);
        });
        this.afAuth.onAuthStateChanged(user => {
            if (user) {
                // logged in or user exists
                console.log(user.email, user.uid);
                this.user = user;
            }
            else {
                // not logged in
                this.user = "";
            }
        });
    }
    ionViewWillEnter() {
        console.log("enter home...");
        console.log(this.itemService.usertype);
        if (this.itemService.usertype == 'visitor' || this.itemService.usertype == '') {
            this.showme = false;
        }
        else {
            this.showme = true;
        }
        console.log(this.showme);
    }
    openAddProductPage() {
        console.log("clicked me");
        this.router.navigate(["/add-product-page"]);
    }
    deleteAndAdd() {
        this.itemService.deleteItem(this.item.id);
        //this.addPage.isFromEdit(true);
        this.openAddProductPage();
        //add fill variable
    }
    deleteItem() {
        this.presentAlertConfirm();
        //  this.itemService.deleteItem(this.item.id);
        //  console.log("item with id: ", this.item.id, "has been deleted");
        //  this.router.navigateByUrl('/tab1/');
    }
    goToEditPage() {
        this.router.navigate(['tabs/edit-product']);
    }
    presentAlertConfirm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: 'Warning',
                message: '<strong>Are you sure you want to delete?</strong>',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Okay',
                        handler: () => {
                            console.log('Confirm Okay');
                            this.itemService.deleteItem(this.item.id).then(() => {
                                console.log("successfully deleted");
                                this.router.navigateByUrl('/');
                            }, err => {
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    orderme() {
        if (this.user.id == null) {
            console.log("You must login to create an order");
            this.router.navigate(["/signin"]);
            return;
        }
        console.log(this.user.id);
        console.log(this.order.quantity);
        // this.order.uid=this.user.uid;
        this.itemService.createOrder(this.item, this.order.quantity);
    }
    change() {
        console.log(this.order.quantity);
        if (this.order.quantity > 50) {
            console.log('thats a lot');
        }
    }
};
ProductDetailPagePage.ctorParameters = () => [
    { type: _item_service__WEBPACK_IMPORTED_MODULE_4__["ItemService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_7__["AngularFireAuth"] }
];
ProductDetailPagePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-product-detail-page',
        template: _raw_loader_product_detail_page_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_product_detail_page_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ProductDetailPagePage);



/***/ }),

/***/ "v1NZ":
/*!*******************************************************************!*\
  !*** ./src/app/product-detail-page/product-detail-page.page.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcm9kdWN0LWRldGFpbC1wYWdlLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "yfrp":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/product-detail-page/product-detail-page.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>ProductDetailPage</ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  \n  <ion-item>\n    <!-- <ion-button slot=\"start\" color=\"warning\" [routerLink]=\"'/edit-product/'\" *ngIf=\"showme\" >Edit</ion-button> -->\n    <ion-button slot=\"start\" color=\"warning\" (click)=\"deleteAndAdd()\" *ngIf=\"showme\" >Edit</ion-button>\n    <ion-button slot=\"end\" color=\"danger\" *ngIf=\"showme\" (click)=\"deleteItem()\" >Delete</ion-button>\n  </ion-item>\n\n\n\n  \n  \n\n  <ion-item>Item: {{item.name}}</ion-item>\n  <ion-item>Price: ${{item.price}}</ion-item>\n  <ion-item>{{item.description}}</ion-item>\n\n  <ion-item>\n      <ion-label> How many in your order?</ion-label>\n  </ion-item>\n\n  <ion-item>\n      <ion-range min=\"1\" max=\"100\" step=\"1\" pin='true'  [(ngModel)]=\"order.quantity\" (ionChange)='change()'>\n            <ion-icon size=\"small\" slot=\"start\" name=\"sunny\"></ion-icon>\n            <ion-icon slot=\"end\" name=\"sunny\"></ion-icon>\n          </ion-range>\n      <p>quantity : {{order.quantity}}</p>\n  </ion-item>\n      \n  <ion-item>\n      <ion-button expand=\"block\" (click)=\"orderme()\" >Add to Cart</ion-button>\n        <!-- <ion-icon slot=\"icon-only\" name=\"add-circle\"></ion-icon> -->\n        \n\n      <!--<ion-button (submit)=\"orderme()\" class=\"submit-btn\" expand=\"block\" type=\"submit\" >Add to Order</ion-button>\n      <ion-button class=\"submit-btn\" expand=\"block\" type=\"submit\" [disabled]=\"!add_item_form.valid\">Add Item</ion-button>-->\n  </ion-item>\n  \n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=product-detail-page-product-detail-page-module.js.map