(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["signin-signin-module"],{

/***/ "0m0A":
/*!*****************************************!*\
  !*** ./src/app/signin/signin.module.ts ***!
  \*****************************************/
/*! exports provided: SigninPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SigninPageModule", function() { return SigninPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _signin_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./signin-routing.module */ "o9hh");
/* harmony import */ var _signin_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./signin.page */ "Pyzx");







let SigninPageModule = class SigninPageModule {
};
SigninPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _signin_routing_module__WEBPACK_IMPORTED_MODULE_5__["SigninPageRoutingModule"]
        ],
        declarations: [_signin_page__WEBPACK_IMPORTED_MODULE_6__["SigninPage"]]
    })
], SigninPageModule);



/***/ }),

/***/ "Pyzx":
/*!***************************************!*\
  !*** ./src/app/signin/signin.page.ts ***!
  \***************************************/
/*! exports provided: SigninPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SigninPage", function() { return SigninPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_signin_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./signin.page.html */ "wuB5");
/* harmony import */ var _signin_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./signin.page.scss */ "QHoY");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/auth */ "UbJi");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase/app */ "Jgta");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");
/* harmony import */ var _item_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../item.service */ "Zr+e");









let SigninPage = class SigninPage {
    constructor(afAuth, itemService, router, firebase) {
        this.afAuth = afAuth;
        this.itemService = itemService;
        this.router = router;
        this.firebase = firebase;
        this.user = { email: "laurantrombetta@gmail.com", password: "mypassword" };
    }
    ngOnInit() {
    }
    signInWithEmail(email, password) {
        // Promise<firebase.auth.UserCredential>
        console.log("signin ...");
        this.afAuth.signInWithEmailAndPassword(email, password).then(user => {
            // navigate to user profile
            console.log(user.user.email, user.user.uid);
            this.itemService.load_my_orders();
            var user1 = firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth().currentUser;
            console.log(user1.uid);
            this.itemService.setUID(user.user.uid);
            // fbService
            var db = firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].firestore();
            var self = this;
            db.collection("usertype").where("uid", "==", user1.uid)
                .get()
                .then(function (querySnapshot) {
                querySnapshot.forEach(function (doc) {
                    // doc.data() is never undefined for query doc snapshots
                    console.log(doc.id, " => ", doc.data());
                    var type = doc.data().usertype;
                    console.log("usertype:" + type);
                    self.itemService.setUsertype(type);
                });
            })
                .catch(function (error) {
                console.log("Error getting documents: ", error);
            });
            this.router.navigate(['tabs/tab1']);
        })
            .catch(error => {
            console.log(error);
        });
    }
    signup() {
        this.router.navigate(["/signup"]);
    }
    loginFacebook() {
        var provider = new firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth.FacebookAuthProvider();
        firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth().signInWithRedirect(provider);
        var self = this;
        firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth()
            .getRedirectResult()
            .then((result) => {
            if (result.credential) {
                /** @type {firebase.auth.OAuthCredential} */
                var credential = result.credential;
                // This gives you a Facebook Access Token. You can use it to access the Facebook API.
                // var token = credential.accessToken;
                // ...
            }
            // The signed-in user info.
            var user = result.user;
            console.log(user);
            self.itemService.setUID(user.uid);
            this.itemService.load_my_orders();
            this.router.navigate(['tabs/tab1']);
        }).catch((error) => {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            // The email of the user's account used.
            var email = error.email;
            // The firebase.auth.AuthCredential type that was used.
            var credential = error.credential;
            // ...
        });
    }
    loginGoogle() {
        var provider = new firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth.GoogleAuthProvider();
        var self = this;
        firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth()
            .signInWithPopup(provider)
            .then((result) => {
            /** @type {firebase.auth.OAuthCredential} */
            var credential = result.credential;
            // This gives you a Google Access Token. You can use it to access the Google API.
            // var token = credential.accessToken;
            // The signed-in user info.
            var user = result.user;
            console.log(user);
            self.itemService.setUID(user.uid);
            self.itemService.load_my_orders();
            self.itemService.setUsertype("visitor");
            this.router.navigate(['tabs/tab1']);
            // ...
        }).catch((error) => {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            // The email of the user's account used.
            var email = error.email;
            // The firebase.auth.AuthCredential type that was used.
            var credential = error.credential;
            // ...
        });
    }
};
SigninPage.ctorParameters = () => [
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__["AngularFireAuth"] },
    { type: _item_service__WEBPACK_IMPORTED_MODULE_8__["ItemService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_7__["AngularFirestore"] }
];
SigninPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-signin',
        template: _raw_loader_signin_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_signin_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SigninPage);



/***/ }),

/***/ "QHoY":
/*!*****************************************!*\
  !*** ./src/app/signin/signin.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzaWduaW4ucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "Zr+e":
/*!*********************************!*\
  !*** ./src/app/item.service.ts ***!
  \*********************************/
/*! exports provided: ItemService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemService", function() { return ItemService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ "I/3d");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/auth */ "UbJi");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase/app */ "Jgta");






//import { url } from 'inspector';
let ItemService = class ItemService {
    constructor(firebase, angularFire) {
        this.firebase = firebase;
        this.angularFire = angularFire;
        this.usertype = "";
        this.uid = '';
        this.menuList = [{ name: "Pasta", price: 5.50, url: "https://www.budgetbytes.com/wp-content/uploads/2013/07/Creamy-Tomato-Spinach-Pasta-V2-bowl.jpg", description: "" },
            { name: "Soup", price: 5.50, url: "https://www.inspiredtaste.net/wp-content/uploads/2018/10/Homemade-Vegetable-Soup-Recipe-4-1200.jpg", description: "" },
            { name: "Burger", price: 15, url: "https://media1.s-nbcnews.com/j/newscms/2019_21/2870431/190524-classic-american-cheeseburger-ew-207p_d9270c5c545b30ea094084c7f2342eb4.fit-2000w.jpg", description: "" },
            { name: "Fruit", price: 9, url: "https://tastesbetterfromscratch.com/wp-content/uploads/2017/06/Fresh-Fruit-Bowl-1-768x1152.jpg", description: "" },
            { name: "Cake", price: 6.20, url: "https://images.immediate.co.uk/production/volatile/sites/2/2019/04/Choc-Fudge-Cake-b2d1909.jpg?webp=true&quality=90&crop=25px%2C1960px%2C5975px%2C2570px&resize=940%2C399", description: "" },
        ];
        this.orderList = [
            { id: 1, quantity: 10, date: '2021-2-10', amount: 23.0 },
            { id: 2, quantity: 10, date: '2021-2-10', amount: 23.0 },
        ];
        this.cartCollection = this.firebase.collection('cart');
        this.orderCollection = this.firebase.collection('orders');
        this.menuCollection = this.firebase.collection('menus');
        this.menu = this.menuCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(actions => {
            return actions.map(a => {
                const data = a.payload.doc.data();
                console.log("menu data...");
                console.log(data);
                const id = a.payload.doc.id;
                return Object.assign({ id }, data);
            });
        }));
        this.order = this.orderCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(actions => {
            return actions.map(a => {
                const data = a.payload.doc.data();
                console.log("Order Data...");
                console.log(data);
                const id = a.payload.doc.id;
                return Object.assign({ id }, data);
            });
        }));
        this.cart = this.cartCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(actions => {
            return actions.map(a => {
                const data = a.payload.doc.data();
                console.log("cart data...");
                console.log(data);
                const id = a.payload.doc.id;
                return Object.assign({ id }, data);
            });
        }));
    }
    load_my_orders() {
        var user = firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth().currentUser;
        console.log(user.uid);
        var uid = user.uid;
        this.orderCollection = this.firebase.collection('orders', ref => ref.where('id', '==', uid));
        this.order = this.orderCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(actions => {
            return actions.map(a => {
                const data = a.payload.doc.data();
                const id = a.payload.doc.id;
                console.log(id);
                return Object.assign({ id }, data);
            });
        }));
        console.log("orders loaded...");
    }
    // load_my_orders(){ //after user login, call this function
    //   var user = firebase.auth().currentUser;
    //   console.log(user.uid);
    //   var uid=user.uid;
    //   // this.noteCollection = this.afs.collection<Note>('notes');
    //   this.orderCollection = this.firebase.collection<Order>('orders',ref => ref.where('uid', '==', uid));
    //   this.order = this.orderCollection.snapshotChanges().pipe(
    //       map(actions => {
    //         return actions.map(a => {
    //           const data = a.payload.doc.data();
    //           // console.log(data)
    //           const id = a.payload.doc.id;
    //           console.log(id)
    //           // console.log("run after aadding new node? ")
    //           return { id, ...data };
    //         });
    //       })
    //   );
    //   console.log("orders  loaded...")
    // }
    setUID(uid) {
        this.uid = uid;
        console.log(this.uid);
    }
    setUsertype(type) {
        this.usertype = type;
    }
    getUsertype() {
        return this.usertype;
    }
    createItem(name, price, url, description) {
        this.menuList.push({ name, price, url, description });
        //this.storage.set('menuList', JSON.stringify(this.menuList));
        var db = this.firebase;
        db.collection("menus").add({
            name: name,
            price: price,
            url: url,
            description: description,
        })
            .then((docRef) => {
            console.log("Document written with ID: ", docRef.id);
        })
            .catch((error) => {
            console.error("Error adding document: ", error);
        });
    }
    // getOrderList(){
    //   return this.orderList;
    // }
    createOrder(item, quantityY) {
        //this.orderList.push({item, quantity});
        var db = this.firebase;
        var d = new Date();
        var user = firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth().currentUser;
        console.log(user.uid);
        var uid = user.uid;
        db.collection("orders").add({
            name: item.name,
            item: item,
            quantity: quantityY,
            date: d.toLocaleDateString(),
            amount: quantityY * item.price,
            uid: uid,
        })
            .then((docRef) => {
            console.log("Document written with ID: ", docRef.id);
        })
            .catch((error) => {
            console.error("Error adding document: ", error);
            // });
            // console.log(item)
            // console.log(quantityY)
            // let orderid=Math.random()*(99999-10000)+10000;
            // var d=new Date();
            // this.orderList.push({
            //   id:orderid,
            //   quantity:quantityY,
            //   date: d.toLocaleDateString(),
            //   amount:quantityY*item.price
            // });
        });
    }
    getOrder() {
        return this.order;
    }
    getCart() {
        return this.cart;
    }
    getMenus() {
        return this.menu;
    }
    getSingleMenu(id) {
        return this.menuCollection.doc(id).valueChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(menu => {
            menu.id = id;
            return menu;
        }));
    }
    updateProductInfo(menu) {
        return this.menuCollection.doc(menu.id).update({ name: menu.name, price: menu.price, url: menu.url, description: menu.description });
    }
    deleteItem(id) {
        return this.menuCollection.doc(id).delete();
    }
    deleteOrder(id) {
        return this.orderCollection.doc(id).delete();
    }
};
ItemService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"] },
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__["AngularFireAuth"] }
];
ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ItemService);



/***/ }),

/***/ "o9hh":
/*!*************************************************!*\
  !*** ./src/app/signin/signin-routing.module.ts ***!
  \*************************************************/
/*! exports provided: SigninPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SigninPageRoutingModule", function() { return SigninPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _signin_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./signin.page */ "Pyzx");




const routes = [
    {
        path: '',
        component: _signin_page__WEBPACK_IMPORTED_MODULE_3__["SigninPage"]
    }
];
let SigninPageRoutingModule = class SigninPageRoutingModule {
};
SigninPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SigninPageRoutingModule);



/***/ }),

/***/ "wuB5":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/signin/signin.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n  \t <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    \n    <ion-title>signin</ion-title>\n  \n\n<ion-buttons slot=\"end\">\n      <ion-button (click)=\"signup()\">\n        <ion-icon slot=\"icon-only\" name=\"add-circle\"></ion-icon>\n        Signup\n      </ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n\n\n</ion-header>\n\n<ion-content>\n\n    <ion-item>\n      <ion-label color=\"primary\" position=\"floating\">email</ion-label>\n      <ion-input type=\"text\" [(ngModel)]=\"user.email\" required></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label color=\"primary\" position=\"floating\">password</ion-label>\n      <ion-input type=\"text\" [(ngModel)]=\"user.password\" required></ion-input>\n    </ion-item>\n\n    <ion-button class=\"submit-btn\" expand=\"block\" type=\"submit\" (click)=\"signInWithEmail(user.email,user.password)\" >Login</ion-button>\n\n  <ion-item>\n  \t<ion-grid>\n  \t\t<ion-button class=\"submit-btn\" (click)=\"loginFacebook()\">Facebook Login</ion-button>\n  \t\t<ion-button class=\"submit-btn\" (click)=\"loginGoogle()\">Google Login</ion-button>\n  \t</ion-grid>\n  </ion-item>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=signin-signin-module.js.map